#include <stdio.h>
#include <unistd.h>

int main()
{
    sleep(5);
    printf("Goodmorning\n");
    return 0;
}